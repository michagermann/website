install.packages("TeachingDemos")
require(TeachingDemos)  # Install package first
txtStart(file="log_Scaling.txt")  # Start recording to log_Scaling.txt


#####################################################################################################
#####################################################################################################
#####################################################################################################
###################################### Replication File (2) #########################################
######### Spatial Maps in Voting Advice Applications: The Case for Dynamic Scale Validation #########
############################### Germann, Mendez, Wheatley, and Serd�lt ##############################
################################### Scaling Analysis (Users) ########################################
#####################################################################################################
#####################################################################################################
#####################################################################################################


# Set memory size to max
memory.size(max=TRUE)


##############################################################################################
####################################### General Comment ######################################
##############################################################################################

##### Note:   all files for scaling analysis must be created in Stata.
#####         "D:/..." is set as directory. If changed, needs be changed in R code as well.




##############################################################################################
################################### Install & load packages ##################################
##############################################################################################


# Install & load packages
install.packages("mokken")
install.packages("poLCA")
install.packages("psych")
install.packages("GPArotation")
library(mokken)
library(poLCA)
library(psych)
library(GPArotation)



##############################################################################################
################## Validation of Ex-ante Dimensions in Early User Sample #####################
##############################################################################################


####### Determination of the adequate number of latent classes for LCRC estimation ############

# Get data (minimum must be 1)
poLCA.exante.early.LR <- read.table("D:/early_LR_poLCA.csv", header=TRUE, sep=",", na.strings="NA", 
                                    dec=".", strip.white=TRUE)
poLCA.exante.early.LibCon <- read.table("D:/early_LibCon_poLCA.csv", header=TRUE, sep=",", 
                                        na.strings="NA", dec=".", strip.white=TRUE)

# Determine number of latent classes (criterion = BCI)

# Left-right (6)
f <- cbind( q1_rev_poLCA, q2_poLCA, q3_poLCA, q6_poLCA, q7_rev_poLCA, q8_rev_poLCA, q9_rev_poLCA,
              q10_rev_poLCA, q15_poLCA, q23_poLCA, q27_poLCA, q28_poLCA, q31_rev_poLCA, q32_rev_poLCA,
              q33_poLCA, q37_poLCA, q38_poLCA, q40_poLCA, q41_poLCA, q43_rev_poLCA, q44_rev_poLCA,
              q48_rev_poLCA, q51_rev_poLCA, q52_rev_poLCA, q53_poLCA, q54_poLCA, q55_poLCA, q56_rev_poLCA, 
              q57_poLCA, q58_rev_poLCA)~1
poLCA(f,poLCA.exante.early.LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LR,nclass = 7, maxiter = 5000,nrep=5)

# Liberal-conservative (7)
f <- cbind(q5_rev_poLCA, q6_rev_poLCA, q9_poLCA, q11_poLCA, q12_rev_poLCA, q13_rev_poLCA, 
           q14_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_poLCA, q20_rev_poLCA, 
           q21_rev_poLCA, q24_rev_poLCA, q25_rev_poLCA, q26_rev_poLCA, q29_rev_poLCA, q33_poLCA, 
           q34_rev_poLCA, q35_rev_poLCA, q36_rev_poLCA, q37_poLCA, q39_poLCA, q44_rev_poLCA, q46_poLCA, 
           q53_rev_poLCA, q59_rev_poLCA, q60_rev_poLCA, q61_rev_poLCA, q62_rev_poLCA, q63_rev_poLCA)~1
poLCA(f,poLCA.exante.early.LibCon,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.early.LibCon,nclass = 8, maxiter = 5000,nrep=5)


###########################################
############ Replicate table 1 ############
###########################################

# Get data  (minimum = 0)

early.LR <- read.table("D:/early_LR.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
early.LibCon <- read.table("D:/early_LibCon.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Confirmatory Mokken
coefH(early.LR )
m.early.LR  <- check.monotonicity(early.LR, minsize = 100)
summary(m.early.LR )
coefH(early.LibCon )
m.early.LibCon  <- check.monotonicity(early.LibCon , minsize = 100)
summary(m.early.LibCon )

# Reliability
check.reliability(early.LR, LCRC=T, nclass=6)
check.reliability (early.LibCon, LCRC=T, nclass=7)



##############################################################################################
########## Quasi-inductive Search for Unidimensional Scales in Early User Sample #############
##############################################################################################


######## Exploratory Mokken (AISP) ###########

# First, we use all items

# Get data  (minimum = 0)
emok63.data <- read.table("D:/emok63.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)


# AISP ( c=.3; only every second scale is shown because items are included in both original and 
# reversed order, which leads to each dimension being created twice)
aisp <- aisp(emok63.data, search = "normal", lowerbound = .3)
coefH(emok63.data[,aisp ==2])
coefH(emok63.data[,aisp ==4])
coefH(emok63.data[,aisp ==5])
coefH(emok63.data[,aisp ==7])
coefH(emok63.data[,aisp ==9])
coefH(emok63.data[,aisp ==11])
coefH(emok63.data[,aisp ==13])
coefH(emok63.data[,aisp ==15])
coefH(emok63.data[,aisp ==17])

# First dimension turns out to combine economic & cultural issues


# In a second step, we thus exclude crossloading items (6, 15, 43, 44, and 45; for this, see below)

# Get data  (minimum = 0)
emok58.data <- read.table("D:/emok58.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# AISP ( c=.3; only every second scale is shown because items are included in both original and reversed order, which leads to each dimension being created twice)
aisp <- aisp(emok58.data, search = "normal", lowerbound = .3)
coefH(emok58.data[,aisp ==2])
coefH(emok58.data[,aisp ==4])
coefH(emok58.data[,aisp ==5])
coefH(emok58.data[,aisp ==7])
coefH(emok58.data[,aisp ==9])
coefH(emok58.data[,aisp ==11])
coefH(emok58.data[,aisp ==13])
coefH(emok58.data[,aisp ==15])
coefH(emok58.data[,aisp ==17])
coefH(emok58.data[,aisp ==19])

# Scales 2 (cultural dimension) & 5 (economic dimension; however without item 41 because it fell below .3, see van Schuur 2003) will be used for further analysis
# Remaining scales consist of only 2-3 items, tend to consist of similarly worded items and thus represent narrow constructs, which moreover are already reflected in scales 2 & 5
# Moreover, exploratory factor analysis confirms two-dimensional structure


########### Exploratory Factor Analysis (polychoric principal axis) ###############
# Get data
efa.data <- read.table("D:/efa.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Scree test
pa.poly <- fa.poly(x=efa.data, fm="pa")
pa.poly$fa$values
plot(pa.poly$fa$values,type="b", main = "Scree plot",ylab="Eigenvalues of factors", 
     ylim=c(0,max(pa.poly$fa$values)) ,xlab="Factor Number",pch=4,col="blue")

# Two-factor solution, promax-rotated (to be preferred if there are items with strong crossloadings, see Thompson 2004)
pa.poly <- fa.poly(x=efa.data, fm="pa", nfactors=2, rotate="promax")
print(pa.poly$fa, digits=3, cut=.3)


########### Show that items 6, 15, 43, 44, and 45 lack external consistency (load on both dimensions with Hi>.3) and should thus be excluded from AISP ###########

# Item 6
Econ.6 <- subset(emok63.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, q38, q6))
Cult.6 <- subset(emok63.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, q60_rev, q61_rev, q62_rev, q6_rev))
coefH(Econ.6)
coefH(Cult.6)

# Item 15
Econ.15 <- subset(emok63.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, q38, q15))
Cult.15 <- subset(emok63.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, q60_rev, q61_rev, q62_rev, q15_rev))
coefH(Econ.15)
coefH(Cult.15)

# Item 43
Econ.43 <- subset(emok63.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, q38, q43_rev))
Cult.43 <- subset(emok63.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, q60_rev, q61_rev, q62_rev, q43))
coefH(Econ.43)
coefH(Cult.43)

# Item 44
Econ.44 <- subset(emok63.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, q38, q44_rev))
Cult.44 <- subset(emok63.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, q60_rev, q61_rev, q62_rev, q44))
coefH(Econ.44)
coefH(Cult.44)

# Item 45
Econ.45 <- subset(emok63.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, q38, q45))
Cult.45 <- subset(emok63.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, q60_rev, q61_rev, q62_rev, q45_rev))
coefH(Econ.45)
coefH(Cult.45)


########### Show that remaining items in scales are externally consistent (load on only one dimension with Hi>.3) ###########

# Add items associated with cultural dimension to the economic dimension
Econ.9 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                       q38, q9_rev))
coefH(Econ.9)
Econ.13 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q13))
coefH(Econ.13)
Econ.14 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q14))
coefH(Econ.14)
Econ.16 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q16))
coefH(Econ.16)
Econ.17 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q17))
coefH(Econ.17)
Econ.18 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q18))
coefH(Econ.18)
Econ.19 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q19_rev))
coefH(Econ.19)
Econ.20 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q20))
coefH(Econ.20)
Econ.50 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q50))
coefH(Econ.50)
Econ.51 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q51_rev))
coefH(Econ.51)
Econ.53 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q53))
coefH(Econ.53)
Econ.55 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q55))
coefH(Econ.55)
Econ.57 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q57))
coefH(Econ.57)
Econ.58 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q58_rev))
coefH(Econ.58)
Econ.60 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q60))
coefH(Econ.60)
Econ.61 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q61))
coefH(Econ.61)
Econ.62 <- subset(emok58.data, select=c(q2, q7_rev, q23, q24_rev, q27, q28, q33, q36_rev, q37, 
                                        q38, q62))
coefH(Econ.62)

# Add items associated with economic dimension to the cultural dimension
Cult.2 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                       q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                       q60_rev, q61_rev, q62_rev, q2_rev))
coefH(Cult.2)
Cult.7 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                       q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                       q60_rev, q61_rev, q62_rev, q7))
coefH(Cult.7)
Cult.23 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q23_rev))
coefH(Cult.23)
Cult.24 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q24))
coefH(Cult.24)
Cult.27 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q27_rev))
coefH(Cult.27)
Cult.28 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q28_rev))
coefH(Cult.28)
Cult.33 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q33_rev))
coefH(Cult.33)
Cult.36 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q36))
coefH(Cult.36)
Cult.37 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q37_rev))
coefH(Cult.37)
Cult.38 <- subset(emok58.data, select=c(q9, q13_rev, q14_rev, q16_rev, q17_rev, q18_rev, q19, 
                                        q20_rev, q50_rev, q51, q53_rev, q55_rev, q57_rev, q58, 
                                        q60_rev, q61_rev, q62_rev, q38_rev))
coefH(Cult.38)


####### Determination of the adequate number of latent classes for LCRC estimation ############

# Get data  (minimum must be 1)
poLCA.qi.early.Econ <- read.table("D:/early_Econ_poLCA.csv", header=TRUE, sep=",", 
                                  na.strings="NA", dec=".", strip.white=TRUE)
poLCA.qi.early.Cult <- read.table("D:/early_Cult_poLCA.csv", header=TRUE, sep=",", 
                                  na.strings="NA", dec=".", strip.white=TRUE)

# Determine number of latent classes (criterion = BCI)

# Economic dimension (5)
f <- cbind( q2_poLCA, q7_rev_poLCA, q23_poLCA, q24_rev_poLCA, q27_poLCA, q28_poLCA, 
            q33_poLCA, q36_rev_poLCA, q37_poLCA, q38_poLCA)~1
poLCA(f,poLCA.qi.early.Econ,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Econ,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Econ,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Econ,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Econ,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Econ,nclass = 6, maxiter = 5000,nrep=5)

# Cultural dimension (5)
f <- cbind( q9_poLCA,  q13_rev_poLCA, q14_rev_poLCA,  q16_rev_poLCA,  q17_rev_poLCA,  q18_rev_poLCA,  
            q19_poLCA,  q20_rev_poLCA,  q50_rev_poLCA,  q51_poLCA,  q53_rev_poLCA,  
            q55_rev_poLCA,  q57_rev_poLCA,  q58_poLCA,  q60_rev_poLCA,  q61_rev_poLCA,  
            q62_rev_poLCA)~1
poLCA(f,poLCA.qi.early.Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.early.Cult,nclass = 6, maxiter = 5000,nrep=5)



###########################################
############ Replicate table 2 ############
###########################################

# Get data  (minimum = 0)
early.Econ <- read.table("D:/early_Econ.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
early.Cult <- read.table("D:/early_Cult.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

# Confirmatory Mokken
coefH(early.Econ)
m.early.Econ <- check.monotonicity(early.Econ, minsize = 100)
summary(m.early.Econ)
coefH(early.Cult)
m.early.Cult <- check.monotonicity(early.Cult, minsize = 100)
summary(m.early.Cult)

# Reliability
check.reliability(early.Econ, LCRC=T, nclass=5)
check.reliability (early.Cult, LCRC=T, nclass=5)






##############################################################################################
########### Validate Both Ex-ante and Quasi-inductive Scales in Late User Sample #############
##############################################################################################

####### Determination of the adequate number of latent classes for LCRC estimation ############

# Get data
poLCA.exante.late.LR <- read.table("D:/late_LR_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
poLCA.exante.late.LibCon <- read.table("D:/late_LibCon_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
poLCA.qi.late.Econ <- read.table("D:/late_Econ_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
poLCA.qi.late.Cult <- read.table("D:/late_Cult_poLCA.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)


# Determine number of latent classes (criterion = BCI)

# Left-right (12)
f <- cbind( q1_rev_poLCA, q2_poLCA, q3_poLCA, q6_poLCA, q7_rev_poLCA, q8_rev_poLCA, q9_rev_poLCA, 
            q10_rev_poLCA, q15_poLCA, q23_poLCA, q27_poLCA, q28_poLCA, q31_rev_poLCA, q32_rev_poLCA, 
            q33_poLCA, q37_poLCA, q38_poLCA, q40_poLCA, q41_poLCA, q43_rev_poLCA, q44_rev_poLCA, 
            q48_rev_poLCA, q51_rev_poLCA, q52_rev_poLCA, q53_poLCA, q54_poLCA, q55_poLCA, 
            q56_rev_poLCA, q57_poLCA, q58_rev_poLCA)~1
poLCA(f,poLCA.exante.late.LR,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LR,nclass = 13, maxiter = 5000,nrep=5)

# Liberal-conservative (12)
f <- cbind(q5_rev_poLCA, q6_rev_poLCA, q9_poLCA, q11_poLCA, q12_rev_poLCA, q13_rev_poLCA, 
           q14_rev_poLCA, q16_rev_poLCA, q17_rev_poLCA, q18_rev_poLCA, q19_poLCA, q20_rev_poLCA, 
           q21_rev_poLCA, q24_rev_poLCA, q25_rev_poLCA, q26_rev_poLCA, q29_rev_poLCA, q33_poLCA, 
           q34_rev_poLCA, q35_rev_poLCA, q36_rev_poLCA, q37_poLCA, q39_poLCA, q44_rev_poLCA, 
           q46_poLCA, q53_rev_poLCA, q59_rev_poLCA, q60_rev_poLCA, q61_rev_poLCA, q62_rev_poLCA, 
           q63_rev_poLCA)~1
poLCA(f,poLCA.exante.late.LibCon,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 12, maxiter = 5000,nrep=5)
poLCA(f,poLCA.exante.late.LibCon,nclass = 13, maxiter = 5000,nrep=5)

# Economic dimension (8)
f <- cbind( q2_poLCA, q7_rev_poLCA, q23_poLCA, q24_rev_poLCA, q27_poLCA, q28_poLCA,  
            q33_poLCA, q36_rev_poLCA, q37_poLCA, q38_poLCA)~1
poLCA(f,poLCA.qi.late.Econ,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Econ,nclass = 9, maxiter = 5000,nrep=5)

# Cultural dimension (11)
f <- cbind( q9_poLCA,  q13_rev_poLCA, q14_rev_poLCA,  q16_rev_poLCA,  q17_rev_poLCA,  q18_rev_poLCA,  
            q19_poLCA,  q20_rev_poLCA,  q50_rev_poLCA,  q51_poLCA,  q53_rev_poLCA,  q55_rev_poLCA,  
            q57_rev_poLCA,  q58_poLCA,  q60_rev_poLCA,  q61_rev_poLCA,  q62_rev_poLCA)~1
poLCA(f,poLCA.qi.late.Cult,nclass = 1, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 2, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 3, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 4, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 5, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 6, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 7, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 8, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 9, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 10, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 11, maxiter = 5000,nrep=5)
poLCA(f,poLCA.qi.late.Cult,nclass = 12, maxiter = 5000,nrep=5)


###########################################
############ Replicate table 3 ############
###########################################

# Get data  (minimum = 0)
late.LR <- read.table("D:/late_LR.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
late.LibCon <- read.table("D:/late_LibCon.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
late.Econ <- read.table("D:/late_Econ.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
late.Cult <- read.table("D:/late_Cult.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

### Confirmatory Mokken

# Ex-ante scales
coefH(late.LR)
m.late.LR <- check.monotonicity(late.LR, minsize = 100)
summary(m.late.LR)
coefH(late.LibCon)
m.late.LibCon <- check.monotonicity(late.LibCon, minsize = 100)
summary(m.late.LibCon)

# Quasi-inductively derived scales
coefH(late.Econ)
m.late.Econ <- check.monotonicity(late.Econ, minsize = 100)
summary(m.late.Econ)
coefH(late.Cult)
m.late.Cult <- check.monotonicity(late.Cult, minsize = 100)
summary(m.late.Cult)

### Reliability 

# Ex-ante scales
check.reliability(late.LR, LCRC=T, nclass=12)
check.reliability (late.LibCon, LCRC=T, nclass=12)

# Quasi-inductively derived scales
check.reliability(late.Econ, LCRC=T, nclass=8)
check.reliability (late.Cult, LCRC=T, nclass=11)


txtStop()  # Stop recording